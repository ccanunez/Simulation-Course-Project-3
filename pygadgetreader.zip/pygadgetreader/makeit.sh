#!/bin/bash

./clean.sh
python setup.py build
python setup.py install
